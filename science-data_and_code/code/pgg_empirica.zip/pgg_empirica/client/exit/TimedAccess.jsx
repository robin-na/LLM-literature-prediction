import { NonIdealState } from "@blueprintjs/core";
import { IconNames } from "@blueprintjs/icons";
import React from "react";
import Countdown from 'react-countdown';
import { experimentDate } from "../../constants";

export default class TimedAccess extends React.Component {
  constructor() {
    super();
    this.state = {
      gistJson: {experimentDate: experimentDate}
    };
  }

// This component configures a timed gate that shows participants a waiting page before the experiment is launched. 
// As currently configured, it will read the experiment date (unix timestamp) from the `constants.js` file. 
// Before this date, this component will render a countdown. After this date, it will inform participants that there are no games available if there are no active batches.
// However, the code block below within componentDidMount allows you to read a datetime from Google Sheets so you can easily change it without redeployment, e.g. if running sessions over multiple days.


//   componentDidMount() {
    
//     const googleSheetsUrl = `[YOUR GOOGLE SHEETS URL]&timestamp=${new Date().getTime()}`;
//     fetch(googleSheetsUrl)
//       .then(response => response.text())
//       .then(text => {
//         const lines = text.split("\n");
//         const header = lines[0].split(",");
//         const data = lines[1].split(",");
//         this.setState({ gistJson: {experimentDate: parseInt(data)} });
        
//       })
// }




  render() {
    const countdownRenderer = ({ days, hours, minutes, seconds, completed }) => {
      return (
        <div style={{ display: 'flex', justifyContent: 'center', gap: '50px' }}>
          {/* <div style={{ textAlign: 'center' }}>
              <div>{days}</div>
              <div style={{ color: 'grey' }}>Days</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div>{hours}</div>
              <div style={{ color: 'grey' }}>Hours</div>
            </div> */}
          <div style={{ textAlign: 'center' }}>
            <div>{minutes}</div>
            <div style={{ color: 'grey' }}>Mins</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div>{seconds}</div>
            <div style={{ color: 'grey' }}>Secs</div>
          </div>
        </div>
      );
    };
    // console.log(this.state.gistJson["experimentDate"]); 

    // this won't automatically change if someone is already on the page when the experimentDate is reached, but should deal with people who arrive after the launch time
    // people who were already there will just be taken to the pre-lobby
    if (Date.now() > this.state.gistJson["experimentDate"]) {
      return (
        <div style={{ marginTop: "5em" }}>
          <NonIdealState
            icon={IconNames.ISSUE}
            title="No experiments available"
            description={
              <div style={{ width: "100%" }}>
                <p>
                  Today's games have all been completed. <strong>Please return the task,</strong> and keep an eye out for notifications about future sessions.
                </p>
              </div>
            }
          />
        </div>
      );
    }
    else {
      return (
        <div style={{ marginTop: "3em" }}>
          <NonIdealState
            icon={IconNames.ISSUE}
            title="Please wait for the next batch to launch!"
            description={
              <div style={{ maxWidth: "60%" }}>
                <p>
                  The next batch of experiments will be available in:
                </p>
                {this.state.gistJson["experimentDate"] ? <h1><Countdown date={this.state.gistJson["experimentDate"]} renderer={countdownRenderer} /></h1> : ""}
                <p>
                  Feel free to step away for a bit, but please be sure to come back before the scheduled time!
                </p>
                <br />
                <p>
                  Once the experiment launches, anticipated playtime would range from 5-50 minutes, depending on the game you are assigned to (duration is random). <strong>If you cannot commit to the full duration of the game, please return the task.</strong>
                </p>
              </div>
            }
          />
          <div style={{ marginLeft: "20%", marginRight: "20%", marginTop: "2rem" }}>
            <h1>When the batch launches, here's what to expect:</h1>
            <p>1. You'll go through an interactive tutorial explaining the game, and then proceed to a brief lobby to wait for other players to complete the instructions.</p>
            <br />
            <p>2. You will play this game simultaneously with other participants, so please stay engaged throughout the entire process, including the lobby. <strong>Participants who are detected to be idle or offline will be removed, and will forfeit their bonuses. </strong></p>
            <br />
            <p>3. If the game goes on for longer than expected, <strong>do not worry about timing out for the task. All submissions from players who complete the game will be accepted.</strong></p>
            <br />
            <p>4. If all seats are filled (which may occur while you are completing the walkthrough), you will see a message that “All games are full” and will not be able to participate in this session. However, you will still be eligible to participate in future sessions, and will be compensated for showing up on time.</p>
          </div>
        </div>
      );
    }
  }
}

