module.exports = (ctx) => {
  // This flag is set when loading configuration by this package.
  const config = {
    plugins: {
      tailwindcss: {},
      autoprefixer: {},
    },
  };

  if (ctx.env === "production") {
    // "autoprefixer" is reported to be slow,
    // so we use it only in production.
    config.plugins.autoprefixer = {
      overrideBrowserslist: ["defaults"],
    };
  }

  return config;
};
