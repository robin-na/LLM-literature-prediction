import { ClassicListenersCollector } from "@empirica/core/admin/classic";
export const Empirica = new ClassicListenersCollector();
import  pggConditions  from "./pggConditions.json";
import 'lodash.combinations';
import _ from 'lodash';

Empirica.onGameStart(({ game }) => {

  game.set("pggConditions", pggConditions);
  game.set("comparisonArray", _.shuffle(_.combinations(_.keys(pggConditions), 2)));
  game.set("binaryArray", _.shuffle(_.keys(pggConditions)));
  game.set("nPairsTotal", game.get("comparisonArray").length);
  game.set("nConditionsTotal", game.get("binaryArray").length); 
  
  // Initialize players with 0 score, otherwise it will be undefined for first pair
  game.players.forEach((player) => {
    player.set("score", 0);
    player.set("comparisons", []); // Array to store comparisons
    player.set("binaryScores", []); // Array to store comparisons
  });

  const round = game.addRound({
    name: "PGG Ratings"
  });

  game.get("binaryArray").forEach((configuration) => {
    round.addStage({ name: "Prediction", duration: 30000000, config: configuration });
  });
  
});

Empirica.onRoundStart(({ round }) => {});

Empirica.onStageStart(({ stage }) => {});

Empirica.onStageEnded(({ stage }) => {});

Empirica.onRoundEnded(({ round }) => {});

Empirica.onGameEnded(({ game }) => {});

